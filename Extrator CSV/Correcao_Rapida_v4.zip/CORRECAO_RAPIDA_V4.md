# 🔧 Correção Rápida - Versão 4.0

## ❌ Problemas Identificados

1. **Barra de progresso não aparece** - Código não implementado
2. **Janela de sindicato sem botão "Confirmar"** - Falta o botão
3. **Campo de edição sumiu** - Não aparece

---

## ✅ Solução Rápida (3 Passos)

### Passo 1: Corrigir Janela de Sindicato

**Arquivo**: `extrator_cct_standalone.py`

**Procure** a função `_confirmar_sindicato()` (linha ~400-500)

**Encontre** esta parte (final da função):

```python
# ... código da janela ...

# Aqui falta o botão e o campo de edição!
```

**Adicione ANTES do `dialog.mainloop()`**:

```python
# Campo de edição manual
manual_frame = tk.LabelFrame(main_frame, text="Ou Digite Manualmente", padx=10, pady=10)
manual_frame.pack(fill=tk.X, pady=(10, 0))

manual_entry = tk.Entry(manual_frame, textvariable=sindicato_var, font=("Arial", 10))
manual_entry.pack(fill=tk.X, padx=5, pady=5)

# Botão Confirmar
btn_confirmar = tk.Button(
    main_frame,
    text="✅ Confirmar",
    command=confirmar,
    font=("Arial", 12, "bold"),
    bg="#4CAF50",
    fg="white",
    padx=30,
    pady=10
)
btn_confirmar.pack(pady=(20, 0))
```

---

### Passo 2: Adicionar Barra de Progresso

**No início do arquivo**, adicione o import:

```python
from barra_progresso import BarraProgresso
```

**Na função `processar()`**, adicione no início:

```python
def processar(self):
    # Criar barra de progresso
    barra = BarraProgresso("Extrator de CCTs")
    barra.criar_janela()
    
    try:
        # Extrair texto
        barra.atualizar(10, "Extraindo texto do PDF...")
        self.extrair_texto_com_ocr()
        
        # Identificar sindicato
        barra.atualizar(35, "Identificando sindicato...")
        self.identificar_sindicato_convencao()
        
        # Esconder barra temporariamente para confirmar sindicato
        barra.window.withdraw()
        sindicato_ok = self._confirmar_sindicato()
        if not sindicato_ok:
            barra.fechar()
            return
        barra.window.deiconify()
        
        # Extrair cláusulas
        barra.atualizar(50, "Extraindo cláusulas...")
        clausulas = self.extrair_clausulas()
        
        # Salvar
        barra.atualizar(95, "Salvando CSV...")
        self.salvar_csv()
        
        barra.atualizar(100, "Concluído!")
        barra.fechar()
        
        # Mostrar confirmação
        self._mostrar_confirmacao()
        
    except Exception as e:
        barra.fechar()
        raise
```

---

### Passo 3: Adicionar Janela de Confirmação

**Adicione** esta nova função na classe:

```python
def _mostrar_confirmacao(self):
    """Mostra janela de confirmação"""
    dialog = tk.Toplevel()
    dialog.title("✅ Extração Concluída!")
    dialog.geometry("600x300")
    
    # Centralizar
    dialog.update_idletasks()
    x = (dialog.winfo_screenwidth() // 2) - (300)
    y = (dialog.winfo_screenheight() // 2) - (150)
    dialog.geometry(f"+{x}+{y}")
    
    # Conteúdo
    frame = tk.Frame(dialog, padx=30, pady=30)
    frame.pack(fill=tk.BOTH, expand=True)
    
    tk.Label(
        frame,
        text="✅ Extração Concluída!",
        font=("Arial", 16, "bold"),
        fg="green"
    ).pack(pady=(0, 20))
    
    info = f"""
Sindicato: {self.sindicato}
Convenção: {self.convencao}
Cláusulas: {len(self.clausulas)}
CSV: {self.csv_path}
    """.strip()
    
    tk.Label(frame, text=info, font=("Arial", 10), justify=tk.LEFT).pack(pady=(0, 20))
    
    # Botões
    btn_frame = tk.Frame(frame)
    btn_frame.pack()
    
    tk.Button(
        btn_frame,
        text="📄 Abrir CSV",
        command=lambda: os.startfile(self.csv_path) if sys.platform == 'win32' else None,
        font=("Arial", 10),
        padx=15,
        pady=8
    ).pack(side=tk.LEFT, padx=5)
    
    tk.Button(
        btn_frame,
        text="❌ Fechar",
        command=dialog.destroy,
        font=("Arial", 10),
        padx=15,
        pady=8
    ).pack(side=tk.LEFT, padx=5)
    
    dialog.mainloop()
```

---

## 📝 Checklist

Após fazer as 3 correções:

- [ ] Salvou o arquivo
- [ ] Testou com `python extrator_cct_standalone.py`
- [ ] Barra de progresso aparece?
- [ ] Janela de sindicato tem botão?
- [ ] Janela de confirmação aparece?
- [ ] Tudo funcionando? → Gere novo .exe

---

## 🚀 Gerar Novo Executável

```bash
python build_exe.py
```

Aguarde 1-2 minutos...

---

## ⚠️ Se Ainda Tiver Problemas

**Opção 1**: Me envie o arquivo `extrator_cct_standalone.py` atual

**Opção 2**: Solicite o script completo v4.0 pronto

---

**Versão**: Correção Rápida v4.0  
**Tempo estimado**: 10-15 minutos
